package com.example.pharmacy.entity;

public enum Role {
    CEO, MANAGER, STAFF
}
