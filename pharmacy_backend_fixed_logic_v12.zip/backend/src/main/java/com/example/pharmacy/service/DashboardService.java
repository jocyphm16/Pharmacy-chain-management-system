package com.example.pharmacy.service;

import com.example.pharmacy.dto.DashboardResponse;
import com.example.pharmacy.entity.Branch;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class DashboardService {
    private final MedicineService medicineService;
    private final InvoiceService invoiceService;
    private final BranchService branchService;
    private final StaffService staffService;

    public DashboardResponse getSummary(Long branchId) {
        Branch branch = null;
        if (branchId != null) {
            branch = branchService.getById(branchId);
        }

        long totalMedicines = medicineService.getAll(branchId, null).size();
        long todayInvoices = invoiceService.getAll(branchId).stream()
                .filter(inv -> inv.createdAt() != null && inv.createdAt().toLocalDate().equals(java.time.LocalDate.now()))
                .count();
        var todayRevenue = invoiceService.revenueToday(branchId);
        long lowStockMedicines = medicineService.getLowStock(branchId, 10).size();
        long expiringMedicines = medicineService.getExpiring(branchId, 30).size();
        long totalStaffs = branchId == null ? staffService.getAll().size() : staffService.countByBranch(branchId);

        return new DashboardResponse(
                branch != null ? branch.getId() : null,
                branch != null ? branch.getName() : "Toan he thong",
                totalMedicines,
                todayInvoices,
                todayRevenue,
                lowStockMedicines,
                expiringMedicines,
                totalStaffs
        );
    }
}
