package com.example.pharmacy.dto;

import java.math.BigDecimal;

public record DashboardResponse(
        Long branchId,
        String branchName,
        long totalMedicines,
        long todayInvoices,
        BigDecimal todayRevenue,
        long lowStockMedicines,
        long expiringMedicines,
        long totalStaffs
) {}
