package com.example.pharmacy.entity;

public enum RestockRequestStatus {
    PENDING,
    APPROVED,
    REJECTED
}
