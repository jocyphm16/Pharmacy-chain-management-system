package com.example.pharmacy.service;

import com.example.pharmacy.dto.RestockRequestCreateRequest;
import com.example.pharmacy.dto.RestockRequestResponse;
import com.example.pharmacy.entity.*;
import com.example.pharmacy.exception.BadRequestException;
import com.example.pharmacy.exception.NotFoundException;
import com.example.pharmacy.repository.RestockRequestRepository;
import com.example.pharmacy.repository.StockImportRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class RestockRequestService {
    private final RestockRequestRepository repository;
    private final MedicineService medicineService;
    private final BranchService branchService;
    private final StaffService staffService;
    private final StockImportRepository stockImportRepository;

    public List<RestockRequestResponse> getAll(Long branchId, String status) {
        List<RestockRequest> list;
        if (branchId != null && status != null && !status.isBlank()) {
            list = repository.findByBranchIdAndStatusOrderByCreatedAtDesc(branchId, RestockRequestStatus.valueOf(status));
        } else if (branchId != null) {
            list = repository.findByBranchIdOrderByCreatedAtDesc(branchId);
        } else if (status != null && !status.isBlank()) {
            list = repository.findByStatusOrderByCreatedAtDesc(RestockRequestStatus.valueOf(status));
        } else {
            list = repository.findAll().stream().sorted((a,b) -> b.getCreatedAt().compareTo(a.getCreatedAt())).toList();
        }
        return list.stream().map(this::toResponse).toList();
    }

    public RestockRequest getEntityById(Long id) {
        return repository.findById(id).orElseThrow(() -> new NotFoundException("Khong tim thay yeu cau nhap hang id=" + id));
    }

    @Transactional
    public RestockRequestResponse create(RestockRequestCreateRequest req) {
        Medicine medicine = medicineService.getEntityById(req.medicineId());
        Branch branch = branchService.getById(req.branchId());
        Staff staff = staffService.getEntityById(req.staffId());
        if (staff.getBranch() == null || !staff.getBranch().getId().equals(branch.getId())) {
            throw new BadRequestException("Nhan vien khong thuoc chi nhanh nay");
        }
        if (medicine.getBranch() == null || !medicine.getBranch().getId().equals(branch.getId())) {
            throw new BadRequestException("Thuoc khong thuoc chi nhanh nay");
        }
        RestockRequest entity = RestockRequest.builder()
                .medicine(medicine)
                .branch(branch)
                .staff(staff)
                .quantity(req.quantity())
                .status(RestockRequestStatus.PENDING)
                .note(req.note())
                .createdAt(LocalDateTime.now())
                .build();
        return toResponse(repository.save(entity));
    }

    @Transactional
    public RestockRequestResponse approve(Long id, Long staffId) {
        RestockRequest request = getEntityById(id);
        if (request.getStatus() != RestockRequestStatus.PENDING) {
            throw new BadRequestException("Yeu cau nay da duoc xu ly");
        }
        Staff manager = staffService.getEntityById(staffId);
        if (manager.getBranch() == null || !manager.getBranch().getId().equals(request.getBranch().getId())) {
            throw new BadRequestException("Ban khong co quyen duyet yeu cau cua chi nhanh khac");
        }
        medicineService.increaseStock(request.getMedicine().getId(), request.getQuantity());
        StockImport stockImport = StockImport.builder()
                .createdAt(LocalDateTime.now())
                .medicine(request.getMedicine())
                .staff(manager)
                .quantity(request.getQuantity())
                .importPrice(request.getMedicine().getImportPrice())
                .note("Duyet yeu cau nhap hang #" + request.getId())
                .build();
        stockImportRepository.save(stockImport);
        request.setStatus(RestockRequestStatus.APPROVED);
        request.setProcessedAt(LocalDateTime.now());
        request.setProcessedBy(manager);
        return toResponse(repository.save(request));
    }

    @Transactional
    public RestockRequestResponse reject(Long id, Long staffId) {
        RestockRequest request = getEntityById(id);
        if (request.getStatus() != RestockRequestStatus.PENDING) {
            throw new BadRequestException("Yeu cau nay da duoc xu ly");
        }
        Staff manager = staffService.getEntityById(staffId);
        request.setStatus(RestockRequestStatus.REJECTED);
        request.setProcessedAt(LocalDateTime.now());
        request.setProcessedBy(manager);
        return toResponse(repository.save(request));
    }

    private RestockRequestResponse toResponse(RestockRequest item) {
        return new RestockRequestResponse(
                item.getId(),
                item.getMedicine() != null ? item.getMedicine().getId() : null,
                item.getMedicine() != null ? item.getMedicine().getName() : "",
                item.getQuantity(),
                item.getStatus().name(),
                item.getNote(),
                item.getCreatedAt(),
                item.getProcessedAt(),
                item.getBranch() != null ? item.getBranch().getId() : null,
                item.getBranch() != null ? item.getBranch().getName() : null,
                item.getStaff() != null ? item.getStaff().getId() : null,
                item.getStaff() != null ? item.getStaff().getFullName() : null,
                item.getProcessedBy() != null ? item.getProcessedBy().getId() : null,
                item.getProcessedBy() != null ? item.getProcessedBy().getFullName() : null
        );
    }
}
