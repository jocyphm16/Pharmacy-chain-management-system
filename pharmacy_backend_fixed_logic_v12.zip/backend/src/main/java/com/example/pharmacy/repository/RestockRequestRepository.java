package com.example.pharmacy.repository;

import com.example.pharmacy.entity.RestockRequest;
import com.example.pharmacy.entity.RestockRequestStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface RestockRequestRepository extends JpaRepository<RestockRequest, Long> {
    List<RestockRequest> findByBranchIdOrderByCreatedAtDesc(Long branchId);
    List<RestockRequest> findByStatusOrderByCreatedAtDesc(RestockRequestStatus status);
    List<RestockRequest> findByBranchIdAndStatusOrderByCreatedAtDesc(Long branchId, RestockRequestStatus status);
}
