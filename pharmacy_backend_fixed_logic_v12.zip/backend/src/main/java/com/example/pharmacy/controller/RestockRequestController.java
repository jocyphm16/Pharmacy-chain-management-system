package com.example.pharmacy.controller;

import com.example.pharmacy.dto.RestockRequestCreateRequest;
import com.example.pharmacy.dto.RestockRequestResponse;
import com.example.pharmacy.service.RestockRequestService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/restock-requests")
@RequiredArgsConstructor
public class RestockRequestController {
    private final RestockRequestService service;

    @GetMapping
    public List<RestockRequestResponse> getAll(@RequestParam(required = false) Long branchId,
                                               @RequestParam(required = false) String status) {
        return service.getAll(branchId, status);
    }

    @PostMapping
    public RestockRequestResponse create(@Valid @RequestBody RestockRequestCreateRequest request) {
        return service.create(request);
    }

    @PutMapping("/{id}/approve")
    public RestockRequestResponse approve(@PathVariable Long id, @RequestBody Map<String, Object> body) {
        Long staffId = ((Number) body.get("staffId")).longValue();
        return service.approve(id, staffId);
    }

    @PutMapping("/{id}/reject")
    public RestockRequestResponse reject(@PathVariable Long id, @RequestBody Map<String, Object> body) {
        Long staffId = ((Number) body.get("staffId")).longValue();
        return service.reject(id, staffId);
    }
}
