package com.example.pharmacy.dto;

import java.time.LocalDateTime;

public record RestockRequestResponse(
        Long id,
        Long medicineId,
        String medicineName,
        Integer quantity,
        String status,
        String note,
        LocalDateTime createdAt,
        LocalDateTime processedAt,
        Long branchId,
        String branchName,
        Long staffId,
        String staffName,
        Long processedById,
        String processedByName
) {}
