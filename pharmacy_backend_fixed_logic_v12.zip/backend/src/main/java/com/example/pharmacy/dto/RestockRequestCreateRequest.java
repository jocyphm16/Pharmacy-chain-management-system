package com.example.pharmacy.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

public record RestockRequestCreateRequest(
        @NotNull Long medicineId,
        @NotNull @Min(1) Integer quantity,
        @NotNull Long branchId,
        @NotNull Long staffId,
        String note
) {}
