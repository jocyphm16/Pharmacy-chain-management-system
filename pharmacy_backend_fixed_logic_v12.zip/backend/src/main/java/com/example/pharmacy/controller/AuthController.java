package com.example.pharmacy.controller;

import com.example.pharmacy.dto.AuthResponse;
import com.example.pharmacy.dto.LoginRequest;
import com.example.pharmacy.service.AuthService;
import com.example.pharmacy.service.StaffService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {
    private final AuthService authService;
    private final StaffService staffService;

    @PostMapping("/login")
    public AuthResponse login(@Valid @RequestBody LoginRequest request) {
        return authService.login(request);
    }

    @PostMapping("/change-password")
    public Map<String, Object> changePassword(@RequestBody Map<String, String> request) {
        staffService.changePassword(
                request.getOrDefault("username", ""),
                request.getOrDefault("oldPassword", request.getOrDefault("old_password", "")),
                request.getOrDefault("newPassword", request.getOrDefault("new_password", ""))
        );
        return Map.of("success", true, "message", "Đổi mật khẩu thành công");
    }
}
